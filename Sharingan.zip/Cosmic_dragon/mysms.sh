#!/bin/bash

# Function to handle installation
install_mysms() {
    echo "Installing MySMS..."
    sudo git clone https://github.com/papusingh2sms/mysms.git
    echo "MySMS installed successfully!"
}

# Function to run Mysms
run_mysms() {
    echo "Running Mysms..."
    cd mysms|| { echo "Error: MySMS directory not found. Install MySMS first."; return; }
    bash mysms.sh
}

# Main menu
while true; do
    echo "MySMS Script"
    echo "----------------"
    echo "1. Install MySMS"
    echo "2. Run MySms"
    echo "3. Exit"
    echo "----------------"
    
    read -rp "Enter your choice: " choice

    case $choice in
        1) install_mysms ;;
        2) run_mysms ;;
        3) exit ;;
        *) echo "Invalid choice. Please select again." ;;
    esac
done
