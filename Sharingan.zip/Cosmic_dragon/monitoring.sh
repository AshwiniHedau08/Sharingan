
# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}


RED='\e[1;31m'
WHITE='\e[0;97m'
GREEN='\e[0;92m'
YELLOW='\e[1;33m'
BLUE='\e[1;36m'
RESET='\e[0m'
sp0='%-40s'
sp1='%-5s'
sp2='%-2s'
# Display menu options
printmenu(){
printf "${YELLOW}${sp0}
				(\_/)
 			    (  =(^Y^)=
  		      _______\_(m___m)__________ "

printf "${RED}
    __  ___            _ __             _
   /  |/  /___  ____  (_) /_____  _____(_)___  ____ _
  / /|_/ / __ \/ __ \/ / __/ __ \/ ___/ / __ \/ __ '/
 / /  / / /_/ / / / / / /_/ /_/ / /  / / / / / /_/ /
/_/  /_/\____/_/ /_/_/\__/\____/_/  /_/_/ /_/\__, /
                                            /____/ \n\n"

printf "${sp2}${GREEN}-------------------------------------------------------------\n"
printf "${sp2}${BLUE}    Monitoring Module \n"
printf "${sp2}${GREEN}-------------------------------------------------------------\n"
printf "${sp1}${WHITE}[1] Monitor Linux System\n"
printf "${sp1}${WHITE}[2] Virtual Memory Stats\n"
printf "${sp1}${WHITE}[3] Ethernet Activity Monitor\n"
printf "${sp1}${WHITE}[4] Real Time IP LAN Monitoring\n"
printf "${sp1}${WHITE}[5] System Process Monitoring\n"
printf "${sp1}${WHITE}[6] Back\n"
printf "${sp2}${GREEN}-------------------------------------------------------------${RESET}\n\n"
}

# Display menu options


# Read user input
main(){
clear
printmenu
printf "${sp2}Enter your choice : "
read choice

# Execute based on user choice
case $choice in
    1)
        # Check if nmon is installed
        if command_exists nmon; then
            echo " Monitoring Linux System......."
            ./nmon.sh
        else
            echo "nmon not found. Do you want to install it?(Y/N)"
	    read install_choice
	    case $install_choice in [yY])
		sudo apt install nmon
	        echo "Successfully installed!......"
		./nmon.sh 
		 ;;
	    *)
	        echo "Exiting....."
		exit 1
		;;
	    esac
        fi
        ;;
    2)
        # Check if Vmstat is installed
        if command_exists vmstat; then
            echo " Displaying Virtual Memory Statistics......."
            ./vmstat.sh
        else
            echo "vmstat not found. Do you want to install it?(Y/N)"
	    read install_choice
	    case $install_choice in [yY])
		sudo apt install vmstat
		echo "Successfully installed!....... Displaying Virtual Memory Stats......"
		./vmstat.sh
		;;
	    *)
		echo "Exiting......."
		exit 1
		;;
	    esac
        fi
        ;;
    3)
        # check if tshark is installed
        if command_exists tshark; then
            echo "Monitoring Ethernet Activity......."
            ./tshark.sh
        else
            echo "tshark not found. Do you want to install it?(Y/N)."
	    read install_choice
	    case $install_choice in [yY])
		sudo apt install tshark
		echo "Successfully installed!....... Monitoring Ethernet Activity........"
		./tshark.sh
		;;
	    *)
		echo "Exiting........"
		exit 1
		;;
	    esac
        fi
        ;;
    4)
        #check if iptraf is installed
        if command_exists iptraf; then
            echo "Running Real time IP LAN Monitoring........"
            ./iptraf.sh
        else
            echo "IPTraf not found. Do you want to install it?(Y/N)"
	    read install_choice
	    case $install_choice in [yY])
		sudo apt install iptraf
		echo "Successfully installed!.......Running Real time IP LAN Monitoring........"
		./iptraf.sh
		;;
	    *)
		echo "Exiting......."
		exit 1
		;;
	    esac
        fi
        ;;
    5)
        #check if top is installed or not
        if command_exists top; then
            echo "Running System Process Monitoring........"
            ./top.sh
        else
            echo "Top not found. Do you want to install it?(Y/N)"
	    read install_choice
	    case $install_choice in [yY])
		sudo apt install top
		echo "Successfully installed!......Running System Process Monitoring......"
		./top.sh
		;;
	    *)
		echo "Exiting......."
		exit 1
		;;
	    esac
        fi
        ;; 
     6)
	   ./main_project.sh
	;;
     *)
        echo "Invalid choice."
        ;;
esac
}
main
