#!/bin/bash

GREEN='\e[92m'
GB='\e[1;92m'
WHITE='\e[0;97m'
YELLOW='\e[33m'
BLUE='\e[34m'
ORANGE='\e[0;93m'
AQUA='\e[1;36m'  # Changing to Aqua for clarity
sp='%-5s'
sp0='%-2s'



# Function to print menu
print_menu() {

    printf "\n${GB}
    _   __     __                      __      ______                                      __  _           
   / | / /__  / /__      ______  _____/ /__   / ____/___  __  ______ ___  ___  _________ _/ /_(_)___  ____ 
  /  |/ / _ \/ __/ | /| / / __ \/ ___/ //_/  / __/ / __ \/ / / / __ '__ \/ _ \/ ___/ __ '/ __/ / __ \/ __ \'
 / /|  /  __/ /_ | |/ |/ / /_/ / /  / ,<    / /___/ / / / /_/ / / / / / /  __/ /  / /_/ / /_/ / /_/ / / / /
/_/ |_/\___/\__/ |__/|__/\____/_/  /_/|_|  /_____/_/ /_/\__,_/_/ /_/ /_/\___/_/   \__,_/\__/_/\____/_/ /_/ 
                                                                                                           \n"

    printf "\n${sp0}${ORANGE}---------------------------------------------"
    printf "\n${sp0}${AQUA}   Network Enumeration Module"
    printf "\n${sp0}${ORANGE}---------------------------------------------"
    printf "\n${sp}${WHITE}[1] Perform network scanning"
    printf "\n${sp}${WHITE}[2] Perform port scanning (common ports)"
    printf "\n${sp}${WHITE}[3] Perform ARP scanning"
    printf "\n${sp}${WHITE}[4] Perform vulnerability scanning"
    printf "\n${sp}${WHITE}[5] Perform port scanning (range of ports)"
    printf "\n${sp}${WHITE}[6] Back"
    printf "\n${sp0}${ORANGE}---------------------------------------------"
}

# Network Enumeration module functions
network_enumeration() {
    while true; do
        echo ""
        printf "${WHITE}Performing network scanning..."
        echo ""
        echo ""
        echo ""
        echo -e "${WHITE}=>${BLUE}a) Nmap"
        echo ""
        echo -e "${WHITE}=>${YELLOW}b) Skipfish"
        echo ""
        echo -e "${WHITE}=>${GREEN}c) Greenbone Vulnerability Manager"
        echo ""
        echo -e "${WHITE}=>${ORANGE}x) Exit"
        echo ""
        read -p "Please select an option: " nmap_choice
        case $nmap_choice in
            a) nmap_options ;;
            b) skipfish_scan ;;
            c) greenbone_vulnerability_manager ;;
            x) return ;;
            *) echo "Invalid choice. Please select again." ;;
        esac
    done
}

# Function for Nmap options
nmap_options() {
    while true; do
        echo ""
    
        echo -e "${WHITE}=>${BLUE}a) Nmap"
        echo ""
        echo -e "${WHITE}=>${YELLOW}b) Skipfish"
        echo ""
        echo -e "${WHITE}=>${GREEN}c) Greenbone Vulnerability Manager"
        echo ""
        echo -e "${WHITE}=>${ORANGE}d) Exit"
        echo ""
        read -p "Please select an option: " nmap_choice
        case $nmap_choice in
            a) nmap_scan ;;
            b) skipfish_scan;;
            c) greenbone_vulnerability_manager ;;
            d) return ;;  # Exit from the function
            *) echo "Invalid choice. Please select again." ;;
        esac
    done
}

nmap_scan() {
    echo "Performing Network Mapping scan..."
    ./nmap.sh
}

skipfish_scan() {
    echo "Performing Skipfish scan..."
    ./skipfish.sh
}

greenbone_vulnerability_manager() {
    echo "Performing Greenbone Vulnerability Manager scan..."
    ./install_gvm_kali.sh
}


# Function to perform port scanning for a domain name
port_scan_domain() {
    read -p 'Enter Domain Name : ' domain 
    echo ""
    echo "Scanning common ports for domain: $domain"
    echo ""
    echo "nmap -F $domain"
    echo ""
    nmap -F $domain
}

# Function to perform port scanning for an IP address
port_scan_ip() {
    read -p 'Enter IP Address : ' ip 
    echo ""
    echo "Scanning common ports for IP address: $ip"
    echo ""
    echo "nmap -F $ip"
    echo ""
    nmap -F $ip
}

# Function to perform ARP scanning
arp_scanning() {
    ./arp_scan_script.sh
}

# Function for vulnerability scanning options
vulnerability_scanning() {
    while true; do
        echo ""
        echo -e "${WHITE}Vulnerability Scanning Options:"
        echo -e "${BLUE}a) Nuclei"
        echo -e "${YELLOW}b) WPScan"
        echo -e "${GREEN}c) Nikto"
        echo -e "${ORANGE}d) Exit"
        echo ""
        read -p "Please select an option: " vulnerability_option
        case $vulnerability_option in
            a) ./nuclei.sh ;;
            b) ./wpscan.sh ;;
            c) ./nikto.sh ;;
            d) return ;;
            *) echo "Invalid choice. Please select again." ;;
        esac
    done
}

# Function to perform Port Scanning in range (1-65535)
port_scanning_range() {
    ./port_scanning_range.sh
}

# Entry point for the script

main(){
while true; do
    clear
    print_menu
    printf "\e[97m\n\n${sp0}Please select an option : "
    read choice
    case $choice in
        1) network_enumeration ;;
        2) 
            echo ""
            echo -e "${WHITE}[1] Enter Domain Name"
            echo -e "${WHITE}[2] Enter IP Address"
            echo -e "${WHITE}[3] Exit"
            echo ""
            read -p "Please select an option: " port_scan_option
            case $port_scan_option in
                1) port_scan_domain ;;
                2) port_scan_ip ;;
                3) ;;
                *) echo "Invalid choice. Please select again." ;;
            esac
            ;;
        3) arp_scanning ;;
        4) vulnerability_scanning ;;
        5) port_scanning_range ;;
        6) ./main_project.sh ;;
        *) echo "Invalid choice. Please select again." ;;
    esac
done
}

main
