echo  "Displaying Virtual Memory Statistics.. "  
                echo ''
                vmstat -w
