#!/bin/bash
# Function to display installation instructions for Nuclei

now=$(date +"%d-%m-%Y-%T")

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

topdf(){
if [ $o == y ]; then
    	cupsfilter Report/nuclei/nuvlun.txt > Report/nuclei/nuclei_${now}_$domain.pdf
    	printf "\nSaved Sucessfully......\n\n"
else
	exit
fi
}

install_nuclei() {
    echo "Nuclei is not installed on your system."
    echo "Installing Nuclei..."
    sudo apt install nuclei
    echo "Nuclei installed successfully!"
}
# Function to run Nuclei scan
run_nuclei_scan() {
    read -p 'Enter Domain Name : ' domain 
    echo ""
    echo "Running Nuclei scan for domain: $domain"
    echo ""
    echo "nuclei -u $domain"
    echo ""
    sed -i '9,$d' Report/nuclei/nuvlun.txt
    nuclei -nc -u $domain | tee -a Report/nuclei/nuvlun.txt
    echo ""
    read -p "Do you want to save the output (y/n) : " o

    if command_exists cupsfilter; then
    	topdf
    else 
    	sudo apt update
    	sudo apt-get -y install cups
    	topdf
    fi

    
    echo ""
}

# Main function
main() {
    run_nuclei_scan
}

# Execute main function
main


