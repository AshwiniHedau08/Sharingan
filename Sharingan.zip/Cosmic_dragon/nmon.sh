#!/bin/bash
echo ''
nmon
