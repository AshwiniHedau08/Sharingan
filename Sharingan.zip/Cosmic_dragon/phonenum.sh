#!/bin/bash

printmenu(){
echo 'Select A Method: '
echo '[1] Phunter'
echo '[2] Ghost-Track'
echo '[0] Back'
}

main(){
printmenu
read -p 'Enter a selected method: ' m
case $m in
1)
phunter
;;
2)
ghost
;;
0)./information_gathering.sh
esac

}

phunter(){
echo 'Enter target phone number: '
echo 'Note:format[+91xxxxxxxxxx]'
read p
cd Phunter
python3 phunter.py -t $p
cd ..
main
}

ghost(){
python3 phone.py
main
}

main
