echo "Monitoring System Processes.."
	echo ''
	top
