#!/bin/bash

# Function to handle installation
install_lockphish() {
    echo "Installing Lockphish..."
    sudo git clone https://github.com/JasonJerry/lockphish.git /opt/lockphish
    echo "Lockphish installed successfully!"
}

# Function to run Lockphish
run_lockphish() {
    echo "Running Lockphish..."
    cd /opt/lockphish || { echo "Error: Lockphish directory not found. Install Lockphish first."; return; }
    bash lockphish.sh
}

# Main menu
while true; do
    echo "Lockphish Script"
    echo "----------------"
    echo "1. Install Lockphish"
    echo "2. Run Lockphish"
    echo "3. Exit"
    echo "----------------"
    
    read -rp "Enter your choice: " choice

    case $choice in
        1) install_lockphish ;;
        2) run_lockphish ;;
        3) exit ;;
        *) echo "Invalid choice. Please select again." ;;
    esac
done
