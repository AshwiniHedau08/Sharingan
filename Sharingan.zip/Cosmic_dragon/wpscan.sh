#!/bin/bash
now=$(date +"%d-%m-%Y-%T")
# Function to display installation instructions for Wpscan
install_wpascan() {
    echo "Wpscan is not installed on your system."
    echo "Installing Wpscan..."
    sudo apt install wpscan
    echo "Wpscan installed successfully!"
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

topdf(){
if [ $o == y ]; then
    	cupsfilter Report/wpscan/wscan.txt > Report/wpscan/wpscan_${now}_$url.pdf
    	printf "\nSaved Sucessfully......\n\n"
else
	exit
fi
}

# Function to run Wpscan scan
run_wpscan_scan() {
    read -p 'Enter full URL : ' url 
    echo ""
    echo "Running Wpscan scan for domain: $url"
    echo ""
    echo "wpscan --url $url"
    echo ""
    #wpscan --url $url
    sed -i '4,$d' Report/wpscan/wscan.txt
    wpscan --url $url | tee -a Report/wpscan/wscan.txt
    echo ""
    read -p "Do you want to save the output (y/n) : " o
    if command_exists cupsfilter; then
    	topdf
    else 
	sudo apt update
	sudo apt-get -y install cups
	topdf
    fi
    echo ""
}

# Main function
main() {
    run_wpscan_scan
}

# Execute main function
main
