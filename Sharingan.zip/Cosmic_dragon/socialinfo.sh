#!/bin/bash

now=$(date +"%d-%m-%Y-%T")

printmenu(){
echo 'select a method: '
echo '[1] Sherlock'
echo '[2] Hawkeye'
echo '[0] Back'
}

main(){
printmenu

read -p 'Select a method: ' n
case $n in
1)
sherlock
;;
2)
hawkeye
;;
0)./information_gathering.sh;;
esac
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

topdf(){
if [ $o == y ]; then
    	cupsfilter Report/sherlock/slock.txt > Report/sherlock/sherlock_${now}_$u.pdf
    	printf "\nSaved Sucessfully......\n\n"
else
	exit
fi
}

topdf2(){
if [ $o == y ]; then
    	cupsfilter Report/black/hawk.txt > Report/black/hawk_${now}_$u.pdf
    	printf "\nSaved Sucessfully......\n\n"
else
	exit
fi
}

sherlock(){
read -p 'Enter username: ' u
sed -i '8,$d' Report/sherlock/slock.txt
cd sherlock
python3 sherlock $u | tee -a ../Report/sherlock/slock.txt
echo ""
cd ..
read -p "Do you want to save the output (y/n) : " o
if command_exists cupsfilter; then
	topdf
else 
	sudo apt update
	sudo apt-get -y install cups
	topdf
fi
sleep 2s
./information_gathering.sh
}

hawkeye(){
read -p 'Please enter username : ' u
sed -i '1,$d' Report/black/hawk.txt
python3 black.py -u $u | tee -a Report/black/hawk.txt
echo ""
read -p "Do you want to save the output (y/n) : " o
if command_exists cupsfilter; then
	topdf2
else 
	sudo apt update
	sudo apt-get -y install cups
	topdf2
fi
sleep 2s
printf '\n'
./information_gathering.sh
}
main
