#!/bin/bash



# Install necessary packages
sudo apt update
sudo apt install -y gvm postgresql nsis

# Run setup script
sudo gvm-setup

# Start gvmd and gsad services
sudo systemctl start gvmd.service && sudo systemctl start gsad.service

# Run check script
sudo gvm-check-setup

# Check gvmd service status
sudo systemctl status gvmd.service

# Check WebUI listening status
sudo ss -ltn4p

# Add default admin user the right to create tasks
sudo gvmd --modify-setting 78eceaec-3385-11ea-b237-28d24461215b --value admin

# Output information
echo "Installation and setup completed."
echo "You can now connect to https://127.0.0.1:9392 with the admin login."
echo "Your username: admin"
echo "Please check your password during the installation process and keep it noted. Thank You!!!"
