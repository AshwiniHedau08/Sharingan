#!/bin/bash

# Function to install aSYNcrone
install_asynchrone() {
    echo "Installing aSYNcrone..."
    git clone https://github.com/fatih4842/aSYNcrone.git
    echo "aSYNcrone installed successfully!"
}

# Function to run aSYNcrone
run_asynchrone() {
    echo "Running aSYNcrone..."
    read -rp "Enter source port: " source_port
    read -rp "Enter target IP: " target_ip
    read -rp "Enter target port: " target_port
    read -rp "Enter thread number: " thread_number

    cd aSYNcrone || { echo "Error: aSYNcrone directory not found."; return 1; }

    gcc aSYNcrone.c -o aSYNcrone -lpthread
    if [ $? -eq 0 ]; then
        ./aSYNcrone "$source_port" "$target_ip" "$target_port" "$thread_number"
    else
        echo "Compilation failed. Exiting."
    fi
}

# Main menu
while true; do
    echo "Welcome to aSYNcrone Script"
    echo "1. Install aSYNcrone"
    echo "2. Run aSYNcrone"
    echo "3. Exit"

    read -rp "Enter your choice: " choice

    case $choice in
        1)
            install_asynchrone
            ;;
        2)
            run_asynchrone
            ;;
        3)
            echo "Exiting aSYNcrone Script. Goodbye!"
            exit 0
            ;;
        *)
            echo "Invalid choice. Please enter a valid option."
            ;;
    esac
done
