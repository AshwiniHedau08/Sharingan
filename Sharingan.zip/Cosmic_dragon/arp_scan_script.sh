#!/bin/bash

# Function to install arp-scan package
install_arp_scan() {
    echo "Installing arp-scan package..."
    sudo apt update
    sudo apt install -y arp-scan
    echo "arp-scan package installed successfully."
}

# Function to perform ARP scanning
arp_scan() {
    sudo arp-scan --localnet
}

# Main menu function
main_menu() {
    echo "ARP Scanning Options:"
    echo "1. Install arp-scan package"
    echo "2. Perform ARP scanning"
    echo "3. Exit"
    read -p "Please select an option: " option
    case $option in
        1) install_arp_scan ;;
        2) arp_scan ;;
        3) exit ;;
        *) echo "Invalid option. Please select again." ;;
    esac
}

# Main execution starts here
while true; do
    main_menu
done
