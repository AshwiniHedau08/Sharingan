#!/bin/bash
now=$(date +"%d-%m-%Y-%T")
# Function to display installation instructions for Nikto
install_nikto() {
    echo "Nikto is not installed on your system."
    echo "Installing Nikto..."
    sudo apt update
    sudo apt install -y nikto
    echo "Nikto installed successfully!"
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

topdf(){
if [ $o == y ]; then
    	cupsfilter Report/nikto/nik.txt > Report/nikto/nikto_${now}_$domain.pdf
    	printf "\nSaved Sucessfully......\n\n"
else
	exit
fi
}

# Check if Nikto is installed
if ! command -v nikto &> /dev/null; then
    install_nikto
fi

# Function to run Nikto scan
run_nikto_scan() {
    read -p 'Enter Domain Name : ' domain 
    echo ""
    echo "Running Nikto scan for domain: $domain"
    echo ""
    echo "nikto --url $domain"
    echo ""
    sed -i '7,$d' Report/nikto/nik.txt
    nikto --url $domain | tee -a Report/nikto/nik.txt
    echo ""
    read -p "Do you want to save the output (y/n) : " o
    if command_exists cupsfilter; then
    	topdf
    else 
    	sudo apt update
    	sudo apt-get -y install cups
    	topdf
    fi
    echo ""
}

# Main function
main() {
    run_nikto_scan
}

# Execute main function
main
