#!/bin/bash

# Prompt user to confirm ngrok setup
read -p "Before installation of Stormbreaker, you have to set up an ngrok server. Have you completed the ngrok setup? (Y/N): " ngrok_setup

# Check user input
if [ "$ngrok_setup" != "Y" ] && [ "$ngrok_setup" != "y" ]; then
    echo "Ngrok setup not completed. Exiting..."
    exit 0
fi

# Clone Stormbreaker repository
echo "Cloning Stormbreaker repository..."
git clone https://github.com/ultrasecurity/Storm-Breaker || { echo "Failed to clone Stormbreaker repository. Exiting..."; exit 1; }

# Change directory to Stormbreaker
cd Storm-Breaker || { echo "Failed to change directory to Stormbreaker. Exiting..."; exit 1; }

# Run installation script
echo "Running Stormbreaker installation script..."
sudo bash install.sh || { echo "Failed to run Stormbreaker installation script. Exiting..."; exit 1; }

# Install Python dependencies manually
echo "Installing Python dependencies..."

sudo apt install -y python3-requests python3-colorama python3-psutil || { echo "Failed to install Python dependencies. Exiting..."; exit 1; }

# Run Stormbreaker
echo "Running Stormbreaker..."
sudo python3 st.py || { echo "Failed to run Stormbreaker. Exiting..."; exit 1; }
