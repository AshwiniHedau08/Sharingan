#!/bin/bash
sp='%-5s'
sp0='%-3s'
GREEN='\e[0;92m'
CYAN='\e[0;36m'
RESET='\e[0m'

now=$(date +"%d-%m-%Y-%T")

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

topdf(){
if [ $o == y ]; then
    	cupsfilter Report/webtech/webtech.txt > Report/webtech/webtech_S_${now}_$u.pdf
    	printf "\nSaved Sucessfully......\n\n"
else
	exit
fi
}

topdf2(){
if [ $o == y ]; then
    	cupsfilter Report/webtech/webtech.txt > Report/webtech/webtech_D_${now}_$u.pdf
    	printf "\nSaved Sucessfully......\n\n"
else
	exit
fi
}

printmenu(){
printf "${CYAN}
  _      __    __       _ __         ______        __             __          _       
 | | /| / /__ / /  ___ (_) /____ ___/_  __/__ ____/ /  ___  ___  / /__  ___ _(_)__ ___
 | |/ |/ / -_) _ \(_-</ / __/ -_)___// / / -_) __/ _ \/ _ \/ _ \/ / _ \/ _ '/ / -_|_-<
 |__/|__/\__/_.__/___/_/\__/\__/    /_/  \__/\__/_//_/_//_/\___/_/\___/\_, /_/\__/___/
                                                                      /___/           \n"
printf "\n${sp0}${GREEN}-------------------------------"
printf "\n${sp0}==> Select a option : "
printf "\n${sp0}${GREEN}-------------------------------${RESET}"
printf "\n${sp}[1] In Short"
printf "\n${sp}[2] In Detail"
printf "\n${sp}[0] Back"
printf "\n${sp0}${GREEN}-------------------------------${RESET}"
}

main(){
printmenu
printf "\n\n${sp0}Enter your option : "
read o
case $o in
1) short ;;
2) detail ;;
0) ./information_gathering.sh ;;
*) echo 'Invalid Option.........' ;;
esac
}

short(){
read -p 'Enter target URL (format: https://example.com): ' u
sed -i '14,$d' Report/webtech/webtech.txt
whatweb --color=never $u | tee -a Report/webtech/webtech.txt
echo ""
read -p "Do you want to save the output (y/n) : " o
if command_exists cupsfilter; then
	topdf
else 
	sudo apt update
	sudo apt-get -y install cups
	topdf
fi
main
}

detail(){
read -p 'Enter target URL (format: https://example.com): ' u
sed -i '14,$d' Report/webtech/webtech.txt
whatweb -v --color=never $u | tee -a Report/webtech/webtech.txt
echo ""
read -p "Do you want to save the output (y/n) : " o
if command_exists cupsfilter; then
	topdf2
else 
	sudo apt update
	sudo apt-get -y install cups
	topdf2
fi
main
}

main
