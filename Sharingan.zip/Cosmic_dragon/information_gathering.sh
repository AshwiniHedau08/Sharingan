#!/bin/bash
clear
GREEN='\e[0;92m'
GB='\e[1;92m'
WHITE='\e[0;97m'
RB='\e[1;31m'
YELLOW='\e[0;33m'
YB='\e[1;33m'
BLUE='\e[0;36m'
BB='\e[1;36m'
RESET='\e[0m'
sp='%-5s'
sp0='%-2s'



# Function to print menu
print_menu() {
clear
    printf "\n ${YB}
    ____      ____                           __  _                ______      __  __              _            
   /  _/___  / __/___  _________ ___  ____ _/ /_(_)___  ____     / ____/___ _/ /_/ /_  ___  _____(_)___  ____ _
   / // __ \/ /_/ __ \/ ___/ __ '__ \/ __ '/ __/ / __ \/ __ \   / / __/ __ '/ __/ __ \/ _ \/ ___/ / __ \/ __ '/
 _/ // / / / __/ /_/ / /  / / / / / / /_/ / /_/ / /_/ / / / /  / /_/ / /_/ / /_/ / / /  __/ /  / / / / / /_/ / 
/___/_/ /_/_/  \____/_/  /_/ /_/ /_/\__,_/\__/_/\____/_/ /_/   \____/\__,_/\__/_/ /_/\___/_/  /_/_/ /_/\__, /  
                                                                                                      /____/   \n"    
    printf "\n${BB}${sp0}----------------------------------------"
    printf "\n${GB}${sp0}    Information Gathering Module"
    printf "\n${BB}${sp0}----------------------------------------"
    printf "\n${WHITE}${sp}[1] Check website status"
    printf "\n${WHITE}${sp}[2] Find Website Technologies"
    printf "\n${WHITE}${sp}[3] Gather social media information"
    printf "\n${WHITE}${sp}[4] Enumerate phone numbers"
    printf "\n${WHITE}${sp}[5] Find sub-domains"
    printf "\n${WHITE}${sp}[6] Back"
    printf "\n${BB}${sp0}----------------------------------------"
}

# Information Gathering module functions
website_status() {
    printf "${BLUE}${sp0}\n==> Please Enter Web-Site name : "
    read n
    printf "\n${YELLOW}Checking Website status.....\n\n"
        
    ping -c 2 $n
    SUCCESS=$?
    if [ $SUCCESS -eq 0 ]
    then
      printf "${sp0}${BLUE}--------------------------------------------\n"
      printf "${sp0}${GB}==> "$n" is Online\n"
      printf "${sp0}${BLUE}--------------------------------------------\n\n"
      end
    else
      printf "${sp0}${RB}----------------------------------------------\n"
      printf "${sp0}${GB}==> "$n" is Offline\n"
      printf "${sp0}${RB}----------------------------------------------\n\n"
      end
    fi
    # Add your website status checking commands here
}

end(){
printf "${BLUE}Do you like to continue.....(Y/n)${WHITE}"
read o
if [ $o == y ]; then
main
else
./main_project.sh
fi
}

web_enum() {
    printf "\nPerforming Web-Site Enumeration..............................................\n\n"
    ./webenum.sh
    # Add your email OSINT commands here
}

social_media_info() {
    printf "\nGathering social media information..."
    ./socialinfo.sh
    # Add your social media information gathering commands here
}

phone_number_enum() {
    printf "\nEnumerating phone numbers..."
    ./phonenum.sh
    # Add your phone number enumeration commands here
}

subdomain_finder() {
    printf "\nFinding sub-domains..."
    ./subdomain.sh
    # Add your sub-domain finding commands here
}

# Entry point for Information Gathering module
main(){
while true; do
    print_menu
    printf "\n\n${RESET}${sp0}Please select an option : "
    read choice
    case $choice in
        1) website_status ;;
        2) web_enum ;;
        3) social_media_info ;;
        4) phone_number_enum ;;
        5) subdomain_finder ;;
        6) ./main_project.sh ;;
        *) echo "Invalid choice. Please select again." ;;
    esac
done
}
main
