#!/bin/bash

now=$(date +"%d-%m-%Y-%T")

# Function to display installation instructions for Nmap
install_nmap() {
    echo "Nmap is not installed on your system."
    echo "Installing Nmap..."
    sudo apt-get install nmap
    echo "Nmap installed successfully!"
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

topdf(){
if [ $o == y ]; then
    	cupsfilter Report/Nmap/netmap.txt > Report/Nmap/nmap_${now}_$target.pdf
    	printf "\nSaved Sucessfully......\n\n"
else
	exit
fi
}

perform_nmap_scan() {
    while true; do
        read -p 'Enter Domain Name or IP Address (or type "exit" to return to the menu) : ' target
        if [ "$target" == "exit" ]; then
            return
        fi

        echo ""
        echo "Performing Nmap scan for target: $target"
        echo ""
        echo "nmap -sV -sT $target"
        echo ""
        sed -i '8,$d' Report/Nmap/netmap.txt
        nmap -sV -sT -Pn $target | tee -a Report/Nmap/netmap.txt
        echo ""
        read -p "Do you want to save the output (y/n) : " o
        if command_exists cupsfilter; then
    		topdf
    	else 
    		sudo apt update
    		sudo apt-get -y install cups
    		topdf
    	fi
    done
}


# Main function
main() {
printf "\n
 _   _                       
| \ | |_ __ ___   __ _ _ __  
|  \| | '_ ' _ \ / _' | '_ \ 
| |\  | | | | | | (_| | |_) |
|_| \_|_| |_| |_|\__,_| .__/ 
                      |_|  \n\n"
    perform_nmap_scan
}

# Execute main function
main
