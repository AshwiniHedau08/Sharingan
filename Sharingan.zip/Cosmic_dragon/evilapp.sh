#!/bin/bash

# Function to handle installation
install_evilapp() {
    echo "Installing EvilApp..."
    sudo git clone https://github.com/crypticterminal/EvilApp.git
    echo "EvilApp installed successfully!"
}

# Function to run Mysms
run_evilapp() {
    echo "Running EvilApp..."
    cd EvilApp|| { echo "Error: EvilApp directory not found. Install EvilApp first."; return; }
    bash evilapp.sh
}

# Main menu
while true; do
    echo "EvilAppScript"
    echo "----------------"
    echo "1. Install EvilApp"
    echo "2. Run EvilApp"
    echo "3. Exit"
    echo "----------------"
    
    read -rp "Enter your choice: " choice

    case $choice in
        1) install_evilapp;;
        2) run_evilapp ;;
        3) exit ;;
        *) echo "Invalid choice. Please select again." ;;
    esac
done
