#!/bin/bash

# Function to install XSpear and required packages
install_xspear() {
    echo "Installing XSpear and required packages..."

    # Set GEM_HOME to $HOME/gems
    export GEM_HOME="$HOME/gems"

    # Step 1: Check Ruby Environment Version
    ruby_version=$(ruby -v)
    echo "Ruby Environment Version: $ruby_version"

    # Step 2: Install required package 1
    sudo gem install colorize || { echo "Failed to install colorize. Exiting..."; exit 1; }

    # Step 3: Install required package 2
    sudo gem install selenium-webdriver || { echo "Failed to install selenium-webdriver. Exiting..."; exit 1; }

    # Step 4: Install required package 3
    sudo gem install terminal-table || { echo "Failed to install terminal-table. Exiting..."; exit 1; }

    # Step 5: Install required package 4
    sudo gem install progress_bar || { echo "Failed to install progress_bar. Exiting..."; exit 1; }

    # Step 6: Install XSpear tool
    gem install XSpear || { echo "Failed to install XSpear. Exiting..."; exit 1; }

    echo "XSpear and required packages installed successfully!"
}

# Function to run XSpear
run_xspear() {
    echo "Running XSpear..."

    echo "XSpear Tool Options:"
    echo "[1] Verbose Mode"
    echo "[2] Scanning XSS"
    echo "[3] Only JSON output"
    echo "[4] Set scanning thread"
    echo "[5] Quiet mode"
    echo "[6] Scanning log"

    read -rp "Enter your choice: " xspear_option
    read -rp "Enter target URL: " target_url

    # Add gem binary directory to PATH
    export PATH="$HOME/.gem/ruby/3.1.2/bin:$PATH"

    case $xspear_option in
        1) read -rp "Enter verbose level: " verbose_level
           xspear -u "$target_url" -v $verbose_level
           ;;
        2) read -rp "Enter XSS payload: " xss_payload
           XSpear -u "$target_url" -d "$xss_payload"
           ;;
        3) read -rp "Enter output format (json/xml): " output_format
           XSpear -u "$target_url" -o "$output_format"
           ;;
        4) read -rp "Enter scanning thread number: " thread_number
           XSpear -u "$target_url" -t "$thread_number"
           ;;
        5) XSpear -u "$target_url" -a
           ;;
        6) read -rp "Enter verbose level: " verbose_level
           XSpear -u "$target_url" -a -v "$verbose_level"
           ;;
        *) echo "Invalid choice. Please select again." ;;
    esac
}

# Main menu
while true; do
    echo "XSpear Script"
    echo "--------------"
    echo "1. Install XSpear"
    echo "2. Run XSpear"
    echo "3. Back"
    echo "--------------"

    read -rp "Enter your choice: " choice

    case $choice in
        1) install_xspear ;;
        2) run_xspear ;;
        3) exit ;;
        *) echo "Invalid choice. Please select again." ;;
    esac
done
