
import json
import requests
import time
import os
import phonenumbers
from phonenumbers import carrier, geocoder, timezone
from sys import stderr

Bl = '\033[30m'  # VARIABLE BUAT WARNA CUYY
Re = '\033[1;31m'
Gr = '\033[1;32m'
Ye = '\033[1;33m'
Blu = '\033[1;34m'
Mage = '\033[1;35m'
Cy = '\033[1;36m'
Wh = '\033[1;37m'
lwh = '\033[0;37m'

User_phone = input(
    f"\n {Wh}Enter phone number target {Gr}Ex [+6281xxxxxxxxx] {Wh}: {Gr}")  # INPUT NUMBER PHONE
default_region = "ID"  # DEFAULT NEGARA INDONESIA

parsed_number = phonenumbers.parse(User_phone, default_region)  # VARIABLE PHONENUMBERS
region_code = phonenumbers.region_code_for_number(parsed_number)
jenis_provider = carrier.name_for_number(parsed_number, "en")
location = geocoder.description_for_number(parsed_number, "id")
is_valid_number = phonenumbers.is_valid_number(parsed_number)
is_possible_number = phonenumbers.is_possible_number(parsed_number)
formatted_number = phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
formatted_number_for_mobile = phonenumbers.format_number_for_mobile_dialing(parsed_number, default_region,
                                                                            with_formatting=True)
number_type = phonenumbers.number_type(parsed_number)
timezone1 = timezone.time_zones_for_number(parsed_number)
timezoneF = ', '.join(timezone1)

print(f"\n {Wh}========== {Gr}SHOW INFORMATION PHONE NUMBERS {Wh}==========")
print(f"\n {Wh}Location             :{Gr} {location}")
print(f" {Wh}Region Code          :{Gr} {region_code}")
print(f" {Wh}Timezone             :{Gr} {timezoneF}")
print(f" {Wh}Operator             :{Gr} {jenis_provider}")
print(f" {Wh}Valid number         :{Gr} {is_valid_number}")
print(f" {Wh}Possible number      :{Gr} {is_possible_number}")
print(f" {Wh}International format :{Gr} {formatted_number}")
print(f" {Wh}Mobile format        :{Gr} {formatted_number_for_mobile}")
print(f" {Wh}Original number      :{Gr} {parsed_number.national_number}")
print(
    f" {Wh}E.164 format         :{Gr} {phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.E164)}")
print(f" {Wh}Country code         :{Gr} {parsed_number.country_code}")
print(f" {Wh}Local number         :{Gr} {parsed_number.national_number}")
if number_type == phonenumbers.PhoneNumberType.MOBILE:
    print(f" {Wh}Type                 :{Gr} This is a mobile number")
elif number_type == phonenumbers.PhoneNumberType.FIXED_LINE:
    print(f" {Wh}Type                 :{Gr} This is a fixed-line number")
else:
    print(f" {Wh}Type                 :{Gr} This is another type of number")

print(f'{lwh}')
