read -p 'Enter Interface Name which you want to monitor  : ' domain 
read -p 'Enter the packet read count (eg. 50) : ' count
                 echo ''
                tshark -c $count -i $domain
