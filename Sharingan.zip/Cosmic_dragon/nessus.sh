#!/bin/bash

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    echo "Please run this script with sudo or as root."
    exit 1
fi

# Function to display installation instructions
installation_instructions() {
    echo "Please download the Nessus .deb package from the Tenable website:"
    echo "https://www.tenable.com/downloads/nessus"
    echo "Then run this script again."
}

# Function to install Nessus
install_nessus() {
    local deb_file="$1"
    sudo dpkg -i "$deb_file"
    sudo apt-get install -f -y
}

# Function to download Nessus .deb package
download_nessus() {
    local url="https://www.tenable.com/downloads/nessus"
    local download_link=$(wget -qO- "$url" | grep -o "https://www\.tenable\.com/downloads/nessus/nessus_[^\"]*\.deb" | head -n 1)
    if [ -z "$download_link" ]; then
        echo "Failed to retrieve download link for Nessus package."
        exit 1
    fi

    local deb_file="$(basename "$download_link")"
    wget "$download_link"
    install_nessus "$deb_file"
}

# Main function
main() {
    download_nessus
    sudo systemctl start nessusd.service

    # Display Nessus URL and instructions
    local nessus_url="https://localhost:8834"
    echo "Nessus installed successfully!"
    echo "Access Nessus using your web browser:"
    echo "$nessus_url"
    echo "Follow the instructions to complete the setup."
}

# Execute main function
main
