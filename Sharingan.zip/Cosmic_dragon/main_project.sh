#!/bin/bash

GREEN='\e[0;32m'
GB='\e[1;92m'
WHITE='\e[0;97m'
RB='\e[1;31m'
YELLOW='\e[0;33m'
YB='\e[2;33m'
BLUE='\e[1;36m'
RESET='\e[0m'
sp='%-5s'
sp0='%-2s'

ex() {
    exit "$1"
}

# Main menu function
main_menu() {
    clear
    printf " ${RB} 

   _____ __               _                       
  / ___// /_  ____ ______(_)___  ____ _____ _____ 
  \__ \/ __ \/ __ '/ ___/ / __ \/ __ '/ __ '/ __ \'
 ___/ / / / / /_/ / /  / / / / / /_/ / /_/ / / / /
/____/_/ /_/\__,_/_/  /_/_/ /_/\__, /\__,_/_/ /_/ 
                              /____/              "

jp2a rin.png --color --size=50x25

    printf "\n${YELLOW}${sp0}-----------------------------------------------------"
    printf "\n${GB}${sp0}    Welcome to Cybersecurity and Forensics Toolset"
    printf "\n${YELLOW}${sp0}-----------------------------------------------------${RESET}"
    printf "\n${sp}[1] Network Enumeration"
    printf "\n${sp}[2] Information Gathering"
    printf "\n${sp}[3] Exploitation"
    printf "\n${sp}[4] Android Hacking"
    printf "\n${sp}[5] Network Monitoring "
    printf "\n${sp}[6] Exit"
    printf "\n${YELLOW}${sp0}-----------------------------------------------------${RESET}"
    printf "\n\n${sp0}Please select a module : "
    read -r choice
    case $choice in
        1) ./network.sh ;;
        2) ./information_gathering.sh ;;
        3) ./exploitation.sh ;;
        4) ./android_hacking.sh ;;
        5) ./monitoring.sh ;;
        6) echo "Exiting......"; ex 0;;
        *) echo "Invalid choice. Please select again." ;;
    esac
}

# Entry point of the script
main_menu
