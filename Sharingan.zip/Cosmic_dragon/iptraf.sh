echo "Displaying Real Time IP LAN Monitoring"
	echo ''
	sudo iptraf -i all
