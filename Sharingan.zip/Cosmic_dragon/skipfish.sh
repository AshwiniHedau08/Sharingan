#!/bin/bash

sudo apt install skipfish
skipfish -h
echo "You can scan the web application URL: "
echo "Example: skipfish -o 202 http://192.168.1.202/wordpress " 
# Prompt user to enter Skipfish command
read -p "Enter the Skipfish command: " skipfish_command

# Execute the Skipfish command provided by the user
echo "Executing Skipfish command: $skipfish_command"
eval "$skipfish_command"
