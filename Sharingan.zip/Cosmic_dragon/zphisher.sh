#!/bin/bash

install_zphisher() {
    echo "Installing Zphisher..."
    git clone --depth=1 https://github.com/htr-tech/zphisher.git || { echo "Failed to clone Zphisher repository. Exiting..."; exit 1; }
    echo "Zphisher installed successfully!"
}

run_zphisher() {
    echo "Running Zphisher..."
    cd zphisher || { echo "Failed to change directory to zphisher. Make sure Zphisher is installed. Exiting..."; exit 1; }
    bash zphisher.sh
}

# Main menu
while true; do
    echo "Zphisher Script"
    echo "---------------"
    echo "1. Install Zphisher"
    echo "2. Run Zphisher"
    echo "3. Back"
    echo "---------------"

    read -rp "Enter your choice: " choice

    case $choice in
        1) install_zphisher ;;
        2) run_zphisher ;;
        3) exit ;;
        *) echo "Invalid choice. Please select again." ;;
    esac
done
