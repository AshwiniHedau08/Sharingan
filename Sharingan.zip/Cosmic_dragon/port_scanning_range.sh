#!/bin/bash

# Function to perform Nmap scan with user-defined port range and IP address
perform_nmap_scan_with_range() {
    read -p 'Enter port range (e.g., 1-65535): ' port_range
    read -p 'Enter IP Address: ' ip_address

    echo ""
    echo "Performing Nmap scan for ports $port_range on IP address $ip_address"
    echo ""

    # Execute Nmap command with user-defined port range and IP address
    nmap -p $port_range $ip_address
}

# Entry point for the script
perform_nmap_scan_with_range
