#!/bin/bash
now=$(date +"%d-%m-%Y-%T")
printmenu(){
echo 'Select a Method: '
echo '[1] Subfinder'
echo '[2] sublist3r'
echo '[0] Back'
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

main(){
printmenu
read -p 'Enter your selected Method: ' o
case $o in
1)
subfind
;;
2)
sublist
;;
0)
./information_gathering.sh
;;
esac

}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

topdf(){
if [ $o == y ]; then
    	cupsfilter Report/subfind/subfind.txt > Report/subfind/subfinder_${now}_$d.pdf
    	printf "\nSaved Sucessfully......\n\n"
else
	exit
fi
}


topdf2(){
if [ $o == y ]; then
    	cupsfilter Report/sublist/sublist.txt > Report/sublist/sublist3r_${now}_$d.pdf
    	printf "\nSaved Sucessfully......\n\n"
else
	exit
fi
}

subfind(){
if command_exists subfinder; then
read -p 'Enter a domain: ' d
sed -i '8,$d' Report/subfind/subfind.txt
subfinder -d $d | tee -a Report/subfind/subfind.txt
echo ""
read -p "Do you want to save the output (y/n) : " o
if command_exists cupsfilter; then
	topdf
else 
	sudo apt update
	sudo apt-get -y install cups
	topdf
fi
main
else
echo 'Subfinder is not installed in your system.....'
echo 'Do you want to install it (y/n)'
read i
if [ i==y ];then
sudo apt update
sudo apt install subfinder 
echo 'Installed Successufully.....'
subfind
else
main
fi
fi
}


sublist(){
if command_exists sublist3r; then
read -p 'Enter a Domain: ' d
sed -i '2,$d' Report/sublist/sublist.txt
sublist3r -n -d $d | tee -a Report/sublist/sublist.txt
echo ""
read -p "Do you want to save the output (y/n) : " o
if command_exists cupsfilter; then
	topdf2
else 
	sudo apt update
	sudo apt-get -y install cups
	topdf2
fi
main
else
echo 'Sublist3r is not installed in your system.....'
echo 'Do you want to install it (y/n)'
read i
if [ i==y ];then
sudo apt update
sudo apt install sublist3r 
echo 'Installed Successufully.....'
sublist
else
main
fi
fi
}

main
