#!/bin/bash

install_dalfox() {
 #   echo "Step 1: Updating package lists..."
  #  sudo apt update || { echo "Failed to update package lists. Exiting..."; exit 1; }

    echo "Step 2: Installing snapd..."
    sudo apt install -y snapd || { echo "Failed to install snapd. Exiting..."; exit 1; }

    echo "Step 3: Enabling and starting snapd and apparmor services..."
    sudo systemctl enable --now snapd apparmor || { echo "Failed to enable and start snapd and apparmor services. Exiting..."; exit 1; }

    echo "Step 4: Installing Dalfox using snapd..."
    sudo snap install dalfox || { echo "Failed to install Dalfox using snapd. Exiting..."; exit 1; }

    echo "Step 5: Updating PATH variable to include /snap/bin..."
    export PATH="$PATH:/snap/bin" || { echo "Failed to update PATH variable. Exiting..."; exit 1; }
    
    echo "Step 6: Checking the help page for Dalfox tools..."
    dalfox --help || { echo "Failed to check Dalfox help page. Exiting..."; exit 1; }


    echo "Dalfox installed successfully!"
}

run_dalfox() {
    read -p "Enter the URL: " url
    read -p "Enter the -b flag value: " blind_url
    dalfox "$url" -b "$blind_url"
}

# Main menu
while true; do
    echo "Dalfox Script"
    echo "-------------"
    echo "1. Install Dalfox"
    echo "2. Run Dalfox"
    echo "3. Exit"
    echo "-------------"

    read -rp "Enter your choice: " choice

    case $choice in
        1) install_dalfox ;;
        2) run_dalfox ;;
        3) exit ;;
        *) echo "Invalid choice. Please select again." ;;
    esac
done
